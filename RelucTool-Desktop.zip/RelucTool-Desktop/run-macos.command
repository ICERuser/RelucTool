#!/bin/sh
# RelucTool Desktop launcher (macOS) - double-click in Finder
cd "$(dirname "$0")"
if ! /usr/libexec/java_home -v 11+ >/dev/null 2>&1 && ! command -v java >/dev/null 2>&1; then
  osascript -e 'display dialog "RelucTool Desktop needs Java 11 or newer. Get it free from adoptium.net" buttons {"OK"}'; exit 1
fi
exec java -Dapple.laf.useScreenMenuBar=true -Dapple.awt.application.name="RelucTool Desktop" -jar RelucTool-Desktop.jar "$@"
