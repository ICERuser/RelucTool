RelucTool Desktop 1.0
=====================

A portable reluctance-network (magnetic equivalent circuit) solver, using the
component models of RelucTool 2.23.3. One self-contained Java program, no
installation and no extra libraries.

REQUIREMENTS
  Java 11 or newer (any vendor). Free download: https://adoptium.net

START
  Windows : double-click run-windows.bat   (or RelucTool-Desktop.jar)
  macOS   : double-click run-macos.command  (first time: right-click > Open)
  Linux   : ./run-linux.sh
  Any OS  : java -jar RelucTool-Desktop.jar [model.json]

The whole folder can live on a USB stick. Your last model is restored on start
(it is autosaved to the .reluctool-desktop folder in your home directory).

WHAT IT DOES
  - Network editor: nodes, magnetic elements (air gap, linear iron, saturable
    iron, circular gap) and field sources (coil N.I, current density J.S,
    magnet). Click a tool and then two nodes, or drag a tool onto the canvas.
  - Bendable branches: select a branch, drag its + handles to bend it along the
    real flux path; smooth, rounded or sharp lines; optional "L from drawing".
  - Numeric solver: nonlinear (saturable B(H)) Newton solution of fluxes, flux
    densities, MMF drops, energies, iron losses, coil inductances and air-gap
    forces by virtual work.
  - Parametric sweep of any parameter with a chart.
  - Symbolic solver: exact closed-form fluxes after series/parallel reduction
    and loop analysis, gap forces, inductances and rotor torque, each checked
    against the numeric solution.
  - Export to Mathematica (.wl) and MATLAB / Octave (.m) scripts.
  - Examples: single- and three-phase transformers, DC motor, induction motor,
    PM synchronous motor, plunger solenoid, C-core electromagnet, PM circuit.
    The same models are in the examples folder as .json files.

FILES
  Models are saved as .json and are compatible with the RelucTool web solver.

KEYBOARD
  V select   N node   1-7 place a component   Esc back to select
  Delete remove selection   Ctrl+Z / Ctrl+Y undo / redo
  Ctrl+O open   Ctrl+S save   Alt while dragging = no grid snap
