#!/bin/sh
# RelucTool Desktop launcher (Linux)
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  echo "RelucTool Desktop needs Java 11 or newer: https://adoptium.net"; exit 1
fi
exec java -jar RelucTool-Desktop.jar "$@"
