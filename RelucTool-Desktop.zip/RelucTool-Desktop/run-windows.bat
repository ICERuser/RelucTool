@echo off
cd /d "%~dp0"
where javaw >nul 2>nul
if errorlevel 1 (
  echo RelucTool Desktop needs Java 11 or newer. Get it free from https://adoptium.net
  pause
  exit /b 1
)
start "" javaw -jar "RelucTool-Desktop.jar" %*
